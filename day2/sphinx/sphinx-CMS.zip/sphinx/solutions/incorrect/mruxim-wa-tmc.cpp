#include "sphinx.h"
using namespace std;

std::vector<int> find_colours(int N, std::vector<int> X, std::vector<int> Y) {
	for(int i = 0; i < 999999; i++)
		perform_experiment(vector<int>(N, 0));
  return {};
}
