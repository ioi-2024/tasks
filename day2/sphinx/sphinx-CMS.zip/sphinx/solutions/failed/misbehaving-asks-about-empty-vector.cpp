#include <vector>

#include "sphinx.h"

using namespace std;

vector<int> find_colours(int N, vector<int> X, vector<int> Y) {
  vector<int> test;
  perform_experiment(test);
  return vector<int>(N, 1);
}