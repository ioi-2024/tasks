#include "sphinx.h"

using namespace std;

vector<int> find_colours(int N, vector<int> X, vector<int> Y) {
  N = N;
  perform_experiment(vector<int>(1e9, -1));
  return vector<int>(N, 0);
}
