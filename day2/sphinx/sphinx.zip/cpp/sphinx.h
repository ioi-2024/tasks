#include <vector>

std::vector<int> find_colours(int N, std::vector<int> X, std::vector<int> Y);

int perform_experiment(std::vector<int> E);
