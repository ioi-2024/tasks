#include "hieroglyphs.h"
#include <vector>

std::vector<int> ucs(std::vector<int> A, std::vector<int> B) {
  return std::vector<int>();
}
