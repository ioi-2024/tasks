#include <vector>

std::vector<int> ucs(std::vector<int> A, std::vector<int> B);
