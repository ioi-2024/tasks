#include<bits/stdc++.h>
#include"hieroglyphs.h"
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;

vector<int> ucs(vector<int> a, vector<int> b)
{
	if(a == b) return a;
	else return {-1};
}