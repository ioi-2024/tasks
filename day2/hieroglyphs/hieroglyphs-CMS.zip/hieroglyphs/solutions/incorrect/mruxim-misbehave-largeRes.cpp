#include <vector>
#include "hieroglyphs.h"

using namespace std;

vector<int> ucs(vector<int> A, vector<int> B) {
    return vector<int>(1e8, 0);
}
