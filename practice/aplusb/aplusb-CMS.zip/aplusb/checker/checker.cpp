#include "testlib.h"

#include <string>
const std::string output_secret = "zX1mLX7DidLevjch8wEUpdRnPEZgvTmq";

int main(int argc, char *argv[])
{
	registerChecker("aplusb", argc, argv);
	readBothSecrets(output_secret);
	readBothGraderResults();
	compareRemainingLines(3);
}
