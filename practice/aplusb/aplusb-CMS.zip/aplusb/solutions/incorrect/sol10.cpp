#include "aplusb.h"

int sum(int A, int B) {
  if (A <= 10 && B <= 10)
    return A + B;
  else
    return 0;
}
