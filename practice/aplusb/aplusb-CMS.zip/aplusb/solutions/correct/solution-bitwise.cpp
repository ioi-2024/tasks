#include "aplusb.h"

int sum(int A, int B) {
  if (B == 0) return A;
  return sum(A ^ B, (A & B) << 1);
}
