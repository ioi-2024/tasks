#include "machine.h"

std::vector<int> find_permutation(int N) {
  std::vector<int> A(N);
  for (int i = 0; i < N; i++)
    A[i] = i;
  std::vector<int> B = use_machine(A);
  return B;
}
