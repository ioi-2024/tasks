#include <bits/stdc++.h>
#include "machine.h"
using namespace std;

vector <int> find_permutation(int n){
    vector<int> q(10);
    for(int i=0;i<300;i++)
    	q[i]=i;
    return q;
}
