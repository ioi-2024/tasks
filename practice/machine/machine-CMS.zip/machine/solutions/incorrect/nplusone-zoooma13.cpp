#include <bits/stdc++.h>
#include "machine.h"
using namespace std;

vector <int> find_permutation(int n){
    vector <int> q(n);
    int x = use_machine(q)[0];

    vector <int> p(n);
    for(int i = 0; i < n; i++){
        q[i] = 1;
        auto r = use_machine(q);
        p[find(r.begin() ,r.end() ,x^1) - r.begin()] = i;
        q[i] = 0;
    }
    return p;
}
