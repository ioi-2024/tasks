#include <bits/stdc++.h>
#include "machine.h"
using namespace std;

vector <int> find_permutation(int n){
    vector <int> q(n);
    int x = use_machine(q)[0];
    iota(q.begin() ,q.end() ,0);

    vector <int> p;
    for(int&i : use_machine(q))
        p.push_back(i^x);
    return p;
}
