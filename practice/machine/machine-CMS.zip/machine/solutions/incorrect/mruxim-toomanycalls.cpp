#include "machine.h"
#include <bits/stdc++.h>

using namespace std;

vector<int> find_permutation(int N) {
	vector<int> A(N);
	for(int i = 0; i < N; i++) A[i] = i << 8;
	for(int i = 0; i < 222; i++)
		A = use_machine(A);
	for(int i = 0; i < N; i++) A[i] >>= 8;
	return A;
}
