#include <bits/stdc++.h>
#include "machine.h"
using namespace std;

vector <int> find_permutation(int n){
    vector <int> q(n);
    iota(q.begin() ,q.end() ,0);

    int x = 0;
    auto r = use_machine(q);
    for(int i = 0; i < n; i++)
        x ^= i^r[i];

    vector <int> p;
    for(int&i : r)
        p.push_back(i^x);
    return p;
}
