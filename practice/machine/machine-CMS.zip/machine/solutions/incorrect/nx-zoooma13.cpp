#include <bits/stdc++.h>
#include "machine.h"
using namespace std;

vector <int> find_permutation(int n){
    vector <int> q(n);
    for(int i = 0; i < n; i++)
        q[i] = i<<8;

    vector <int> p;
    for(int&i : use_machine(q))
        p.push_back(i>>8);
    return p;
}
