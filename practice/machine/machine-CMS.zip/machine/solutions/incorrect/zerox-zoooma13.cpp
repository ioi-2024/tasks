#include <bits/stdc++.h>
#include "machine.h"
using namespace std;

vector <int> find_permutation(int n){
    vector <int> q(n);
    iota(q.begin() ,q.end() ,0);
    return use_machine(q);
}
