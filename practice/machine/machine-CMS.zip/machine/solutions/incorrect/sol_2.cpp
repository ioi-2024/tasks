#include <bits/stdc++.h>
#include "machine.h"

using namespace std;

vector<int> find_permutation(int n)
{
	vector<int> v(n,0);
	auto ret=use_machine(v);
	int x=ret[0];
	for(int i=0;i<v.size();i++)
		v[i]=i;
	v=use_machine(v);
	for(int i=0;i<v.size();i++)
	    v[i]=v[i]^x;
	return v;
}
