#include <bits/stdc++.h>
#include "machine.h"
using namespace std;

vector <int> find_permutation(int n){
    vector <int> q(n) ,iq(n+5);
    iota(q.begin() ,q.end() ,0);
    iota(iq.begin() ,iq.end() ,0);
    int w = 1;
    while(w+w <= n)
        w = w+w;
    if(w+w <= n+2){
        q[n-1] = w+w;
        iq[w+w] = n-1;
    }
    else{
        q[w-1] = n;
        iq[n] = w-1;
    }

    auto r = use_machine(q);
    for(int b = 0; b < 30; b++){
        int t = 0;
        for(int&i : r)
            t += i>>b&1;
        if(t+t < n)
            continue;
        for(int&i : r)
            i ^= 1<<b;
    }

    vector <int> p;
    for(int&i : r)
        p.push_back(iq[i]);
    return p;
}
