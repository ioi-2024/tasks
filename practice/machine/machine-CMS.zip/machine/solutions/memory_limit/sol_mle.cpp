#include <bits/stdc++.h>
#include "machine.h"
using namespace std;

vector <int> find_permutation(int n){
    vector<int> q;
    while(true)
    	q.push_back(10);
    return q;
}
