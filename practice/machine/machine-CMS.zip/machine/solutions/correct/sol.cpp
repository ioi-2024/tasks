#include <bits/stdc++.h>
#include "machine.h"

using namespace std;

int ok(int n,int a,int b,int c)
{
	int co[8]={};
	for(int i=0;i<=n+2;i++)
	{
		if(i==a||i==b||i==c) continue;
		for(int j=0;j<8;j++)
			if(i&(1<<j)) co[j]++;
	}
	for(int i=0;i<8;i++)
		if(co[i]*2==n) return 0;
	return 1;
}

vector<int> ans[129];

vector<int> get(int n)
{
	if(ans[n].size()) return ans[n];
	vector<int> v;
	int got=0;
	for(int i=0;i<=n+2&&!got;i++)
	{
		for(int j=i+1;j<=n+2&&!got;j++)
		{
			for(int k=j+1;k<=n+2&&!got;k++)
			{
				if(ok(n,i,j,k))
				{
					got=1;
					for(int x=0;x<=n+2;x++)
					{
						if(x==i||x==j||x==k) continue;
						v.push_back(x);
					}
				}
			}
		}
	}
	ans[n]=v;
	return ans[n];
}

vector<int> find_permutation(int n)
{
	vector<int> v=get(n);
	int co[33]={};
	int co2[33]={};
	vector<int> ret=use_machine(v);
	for(int i:v)
		for(int j=0;j<30;j++)
			co[j]+=(i&(1<<j))>0;
	for(int i:ret)
		for(int j=0;j<30;j++)
			co2[j]+=(i&(1<<j))>0;
	int x=0;
	for(int i=0;i<30;i++)
		if(co[i]!=co2[i]) x|=(1<<i);
	for(int i=0;i<(int)ret.size();i++)
		ret[i]^=x;
	vector<int> perm;
	for(int i=0;i<(int)ret.size();i++)
	{
		perm.push_back(lower_bound(v.begin(),v.end(),ret[i])-v.begin());
	}
	return perm;
}
