#include <bits/stdc++.h>
#include "machine.h"
using namespace std;

vector <int> find_permutation(int n){
    for(int i=0;;i++)
    {
    	vector<int> v(n,0);
    	use_machine(v);
    }
    return vector<int>();
}
