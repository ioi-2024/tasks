#include "machine.h"
#include <cstdio>
#include <cstdlib>
#include <csignal>
#include <string>

using namespace std;


namespace {

/******************************** Begin testlib-related material ********************************/
#ifdef _MSC_VER
#   define NORETURN __declspec(noreturn)
#elif defined __GNUC__
#   define NORETURN __attribute__ ((noreturn))
#else
#   define NORETURN
#endif
/********************************* End testlib-related material *********************************/


// utils

#define rep(i, n) for(int i = 0, i##__n = (int)(n); i < i##__n; ++i)

template<class C> int sz(const C& c) { return std::size(c); }

typedef pair<int, int> PII;
typedef vector<int> VI;
typedef vector<PII> VPII;

// grader/manager protocol

const int secret_g2m = 0x4B213850;
const int secret_m2g = 0x3459AC10;
const int code_mask  = 0x0000000F;

const int M2G_CODE__OK = 0;
const int M2G_CODE__DIE = 1;

const int G2M_CODE__OK_QUERY = 0;
const int G2M_CODE__OK_RESULT = 1;
const int G2M_CODE__QUERY_ARRAY_SIZE_INCORRECT = 2;
const int G2M_CODE__RESULT_VECTOR_SIZE_INCORRECT = 3;
const int G2M_CODE__PV_CALL_EXIT = 13;
const int G2M_CODE__PV_TAMPER_M2G = 14;
const int G2M_CODE__SILENT = 15;


bool exit_allowed = false;

NORETURN void authorized_exit(int exit_code) {
  exit_allowed = true;
  exit(exit_code);
}


FILE* fin = stdin;
FILE* fout = stdout;

void out_flush() {
	fflush(fout);
}

void write_int(int x, const string& delim="") {
	if (0 >= fprintf(fout, "%d%s", x, delim.c_str())) {
		fprintf(stderr, "Could not write int to fout\n");
		authorized_exit(3);
	}
}

void write_int_vector(vector<int> &v) {
	const int len = sz(v);
	rep(i, len)
		write_int(v[i], ((i == len-1) ? "\n" : " "));
}

void write_secret(int g2m_code) {
	write_int(secret_g2m | g2m_code, "\n");
	out_flush();
}

NORETURN void die(int g2m_code) {
	if(g2m_code == G2M_CODE__OK_QUERY || g2m_code == G2M_CODE__OK_RESULT) {
		fprintf(stderr, "Shall not die with code OK\n");
		authorized_exit(5);
	}
	fprintf(stderr, "Dying with code %d\n", g2m_code);
	if(g2m_code != G2M_CODE__SILENT)
		write_secret(g2m_code);
	fclose(fin);
	fclose(fout);
	authorized_exit(0);
}


int read_int() {
	int x;
	if (1 != fscanf(fin, "%d", &x)) {
		fprintf(stderr, "Could not read int from fin\n");
		authorized_exit(3);
	}
	return x;
}

vector<int> read_int_vector(int len) {
	vector<int> r(len);
	rep(i, len) r[i] = read_int();
	return r;
}

void read_secret() {
	int secret = read_int();
	if((secret & ~code_mask) != secret_m2g)
		die(G2M_CODE__PV_TAMPER_M2G);
	int m2g_code = secret & code_mask;
	if (m2g_code != M2G_CODE__OK)
		die(G2M_CODE__SILENT);
}

void check_exit_protocol() {
  if (!exit_allowed)
    die(G2M_CODE__PV_CALL_EXIT);
}


// grader logic

int N;

} // namespace


vector<int> use_machine(vector<int> A) {
    if(sz(A) != N)
		die(G2M_CODE__QUERY_ARRAY_SIZE_INCORRECT);

	write_secret(G2M_CODE__OK_QUERY);
	write_int_vector(A);
	out_flush();

	read_secret();
	return read_int_vector(N);
}

int main() {
	signal(SIGPIPE, SIG_IGN);
	atexit(check_exit_protocol);
	at_quick_exit(check_exit_protocol);

	while(true) {
		read_secret();
		N = read_int();
		if(N == -1) break;

		vector<int> R = find_permutation(N);

		if(sz(R) != N)
			die(G2M_CODE__RESULT_VECTOR_SIZE_INCORRECT);

		write_secret(G2M_CODE__OK_RESULT);
		write_int_vector(R);
		out_flush();
	}

	die(G2M_CODE__SILENT);
}
