#include "testlib.h"
#include <csignal>
#include <cassert>
#include <vector>
#include <utility>
#include <algorithm>
#include <random>

using namespace std;


/******************************** Begin testlib-related material ********************************/

inline FILE* openFile(const char* name, const char* mode) {
	FILE* file = fopen(name, mode);
	if (!file)
		quitf(_fail, "Could not open file '%s' with mode '%s'.", name, mode);
	closeOnHalt(file);
	return file;
}


vector<FILE*> mgr2sol, sol2mgr;
FILE* log_file = nullptr;

void nullifyFile(int idx) {
	mgr2sol[idx] = sol2mgr[idx] = nullptr;
}

#ifdef __GNUC__
__attribute__ ((format (printf, 1, 2)))
#endif
void log_printf(const char* fmt, ...) {
	if (log_file) {
		FMT_TO_RESULT(fmt, fmt, message);
		fprintf(log_file, "%s", message.c_str());
		fflush(log_file);
	}
}

void registerManager(std::string probName, int num_processes, int argc, char* argv[]) {
	setName("manager for problem %s", probName.c_str());
	__testlib_ensuresPreconditions();
	testlibMode = _checker;
	random_t::version = 1; // Random generator version
	__testlib_set_binary(stdin);
	ouf.mode = _output;

	{//Keep alive on broken pipes
		//signal(SIGPIPE, SIG_IGN);
		struct sigaction sa;
		sa.sa_handler = SIG_IGN;
		sigaction(SIGPIPE, &sa, NULL);
	}

	int required_args = 1 + 2 * num_processes;
	if (argc < required_args || required_args+1 < argc) {
		string usage = format("'%s'", argv[0]);
		for (int i = 0; i < num_processes; i++)
			usage += format(" sol%d-to-mgr mgr-to-sol%d", i, i);
		usage += " [mgr_log] < input-file";
		quitf(_fail,
			"Manager for problem %s:\n"
			"Invalid number of arguments: %d\n"
			"Usage: %s",
			probName.c_str(), argc-1, usage.c_str());
	}

	inf.init(stdin, _input);
	closeOnHalt(stdout);
	closeOnHalt(stderr);

	mgr2sol.resize(num_processes);
	sol2mgr.resize(num_processes);
	for (int i = 0; i < num_processes; i++) {
		mgr2sol[i] = openFile(argv[1 + 2*i + 1], "a");
		sol2mgr[i] = openFile(argv[1 + 2*i + 0], "r");
	}

	if (argc > required_args) {
		log_file = openFile(argv[required_args], "w");
	} else {
		log_file = nullptr;
	}
}
/********************************* End testlib-related material *********************************/


// utils

#define all_of(c) (std::begin(c)), (std::end(c))
#define rep(i, n) for(int i = 0, i##__n = (int)(n); i < i##__n; ++i)

template<class C> int sz(const C& c) { return std::size(c); }

typedef pair<int, int> PII;
typedef vector<int> VI;
typedef vector<PII> VPII;

// grader/manager protocol

const int secret_g2m = 0x4B213850;
const int secret_m2g = 0x3459AC10;
const int code_mask  = 0x0000000F;

const int M2G_CODE__OK = 0;
const int M2G_CODE__DIE = 1;

const int G2M_CODE__OK_QUERY = 0;
const int G2M_CODE__OK_RESULT = 1;
const int G2M_CODE__QUERY_ARRAY_SIZE_INCORRECT = 2;
const int G2M_CODE__RESULT_VECTOR_SIZE_INCORRECT = 3;
const int G2M_CODE__PV_CALL_EXIT = 13;
const int G2M_CODE__PV_TAMPER_M2G = 14;
const int G2M_CODE__SILENT = 15;


int fifo_idx = 0;
bool mode_query;

void out_flush() {
	fflush(mgr2sol[fifo_idx]);
}

void write_int(int x, const string& delim="") {
	if (0 >= fprintf(mgr2sol[fifo_idx], "%d%s", x, delim.c_str())) {
		nullifyFile(fifo_idx);
		log_printf("Could not write int to mgr2sol[%d]\n", fifo_idx);
	}
}

void write_int_vector(vector<int> &v) {
	const int len = sz(v);
	rep(i, len)
		write_int(v[i], ((i == len-1) ? "\n" : " "));
}

void write_secret(int m2g_code = M2G_CODE__OK) {
	write_int(secret_m2g | m2g_code, "\n");
	out_flush();
}


#ifdef __GNUC__
__attribute__ ((format (printf, 2, 3)))
#endif
NORETURN void die(TResult result, const char* format, ...) {
	FMT_TO_RESULT(format, format, message);
	log_printf("Dying with message '%s'\n", message.c_str());
	rep(i, sz(mgr2sol))
		if(mgr2sol[i] != nullptr) {
			log_printf("Sending secret with code DIE to mgr2sol[%d]\n", i);
			fifo_idx = i;
			out_flush();
			write_secret(M2G_CODE__DIE);
		}
	log_printf("Quitting with result code %d\n", int(result));
	quit(result, message);
}

void die_invalid_argument(const string &msg) {
	RESULT_MESSAGE_WRONG += ": Invalid argument";
	die(_wa, "%s", msg.c_str());
}

void die_too_many_calls(const string &msg) {
	RESULT_MESSAGE_WRONG += ": Too many calls";
	die(_wa, "%s", msg.c_str());
}


int read_int() {
	int x;
	if (1 != fscanf(sol2mgr[fifo_idx], "%d", &x)) {
		nullifyFile(fifo_idx);
		die(_fail, "Could not read int from sol2mgr[%d]", fifo_idx);
	}
	return x;
}

vector<int> read_int_vector(int len) {
	vector<int> r(len);
	rep(i, len) r[i] = read_int();
	return r;
}

void read_secret() {
	int secret = read_int();
	if((secret & ~code_mask) != secret_g2m)
		die(_pv, "Possible tampering with sol2mgr[%d]", fifo_idx);
	int g2m_code = secret & code_mask;
	switch (g2m_code) {
		case G2M_CODE__OK_QUERY:
			mode_query = true;
			return;
		case G2M_CODE__OK_RESULT:
			mode_query = false;
			return;
		case G2M_CODE__SILENT:
			die(_fail, "Unexpected g2m_code SILENT from sol2mgr[%d]", fifo_idx);
		case G2M_CODE__PV_TAMPER_M2G:
			die(_pv, "Possible tampering with mgr2sol[%d]", fifo_idx);
		case G2M_CODE__PV_CALL_EXIT:
			die(_pv, "Solution[%d] called exit()", fifo_idx);
		case G2M_CODE__QUERY_ARRAY_SIZE_INCORRECT:
			die_invalid_argument("Query vector size is incorrect");
		case G2M_CODE__RESULT_VECTOR_SIZE_INCORRECT:
			die(_wa, "Result vector size is incorrect");
		default:
			die(_fail, "Unknown g2m_code %d from sol2mgr[%d]", g2m_code, fifo_idx);
	}
}


const int subtasks_cnt = 6;
const int max_calls[subtasks_cnt + 1] = {  129,   129,     2,     1,  1,  1,  1};
const int A_max_val[subtasks_cnt + 1] = {32767, 32767, 32767, 32767, -2, -1, -1};

int main(int argc, char **argv) {
	registerManager("machine", 1, argc, argv);

	// Reading Input
	int subtask_id = inf.readInt();
	int T = inf.readInt();

	rep(scenario_idx, T) {
		int N = inf.readInt(), X = inf.readInt();
		vector<int> P = inf.readInts(N, -1e9, 1e9);

		write_secret();
		write_int(N, "\n");
		out_flush();

		int calls_cnt = 0;
		int max_val = A_max_val[subtask_id];
		if(max_val == -2) max_val = 2 * N;
		if(max_val == -1) max_val = N + 2;

		while(true) {
			read_secret();
			if(mode_query == false) break;

			vector<int> A = read_int_vector(N);

			calls_cnt++;
			if(calls_cnt > max_calls[subtask_id])
				die_too_many_calls("Too many queries");

			rep(i, N)
				if(!(0 <= A[i] && A[i] <= max_val))
					die_invalid_argument("Invalid element in query vector");

			vector<int> B(N);
			rep(i, N) B[i] = A[P[i]] ^ X;

			write_secret();
			write_int_vector(B);
			out_flush();
		}

		vector<int> R = read_int_vector(N);

		if(R != P)
			die(_wa, "Incorrect result");
	}
	write_secret();
	write_int(-1, "\n");

	quitf(_ok, "Correct");

    return 0;
}
