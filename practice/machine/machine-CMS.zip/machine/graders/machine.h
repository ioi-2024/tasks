#include <vector>

std::vector<int> find_permutation(int N);
std::vector<int> use_machine(std::vector<int> A);
