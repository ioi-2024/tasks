#include "treasure.h"

std::vector<int> encode(std::vector<std::pair<int, int>> P) {
  return std::vector<int>();
}

std::vector<std::pair<int, int>> decode(std::vector<int> S) {
  return std::vector<std::pair<int, int>>();
}
