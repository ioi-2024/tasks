#include <vector>
#include <utility>

std::vector<int> encode(std::vector<std::pair<int, int>> P);
std::vector<std::pair<int, int>> decode(std::vector<int> S);
