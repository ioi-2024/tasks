#include "testlib.h"
#include <csignal>
#include <cassert>
#include <vector>
#include <utility>
#include <algorithm>
#include <random>

using namespace std;


/******************************** Begin testlib-related material ********************************/

inline FILE* openFile(const char* name, const char* mode) {
	FILE* file = fopen(name, mode);
	if (!file)
		quitf(_fail, "Could not open file '%s' with mode '%s'.", name, mode);
	closeOnHalt(file);
	return file;
}


vector<FILE*> mgr2sol, sol2mgr;
FILE* log_file = nullptr;


#ifdef __GNUC__
__attribute__ ((format (printf, 1, 2)))
#endif
void log_printf(const char* fmt, ...) {
	if (log_file) {
		FMT_TO_RESULT(fmt, fmt, message);
		fprintf(log_file, "%s", message.c_str());
		fflush(log_file);
	}
}

void registerManager(std::string probName, int num_processes, int argc, char* argv[]) {
	setName("manager for problem %s", probName.c_str());
	__testlib_ensuresPreconditions();
	testlibMode = _checker;
	random_t::version = 1; // Random generator version
	__testlib_set_binary(stdin);
	ouf.mode = _output;

	{//Keep alive on broken pipes
		//signal(SIGPIPE, SIG_IGN);
		struct sigaction sa;
		sa.sa_handler = SIG_IGN;
		sigaction(SIGPIPE, &sa, NULL);
	}

	int required_args = 1 + 2 * num_processes;
	if (argc < required_args || required_args+1 < argc) {
		string usage = format("'%s'", argv[0]);
		for (int i = 0; i < num_processes; i++)
			usage += format(" sol%d-to-mgr mgr-to-sol%d", i, i);
		usage += " [mgr_log] < input-file";
		quitf(_fail,
			"Manager for problem %s:\n"
			"Invalid number of arguments: %d\n"
			"Usage: %s",
			probName.c_str(), argc-1, usage.c_str());
	}

	inf.init(stdin, _input);
	closeOnHalt(stdout);
	closeOnHalt(stderr);

	mgr2sol.resize(num_processes);
	sol2mgr.resize(num_processes);
	for (int i = 0; i < num_processes; i++) {
		mgr2sol[i] = openFile(argv[1 + 2*i + 1], "a");
		sol2mgr[i] = openFile(argv[1 + 2*i + 0], "r");
	}

	if (argc > required_args) {
		log_file = openFile(argv[required_args], "w");
	} else {
		log_file = nullptr;
	}
}
/********************************* End testlib-related material *********************************/


// utils

#define all_of(c) (std::begin(c)), (std::end(c))
#define rep(i, n) for(int i = 0, i##__n = (int)(n); i < i##__n; ++i)

template<class C> int sz(const C& c) { return std::size(c); }


// grader/manager protocol

typedef pair<int, int> PII;
#define X first
#define Y second

typedef vector<int> VI;
typedef vector<PII> VPII;

const int secret_g2m = 0x60952B90;
const int secret_m2g = 0x046A1620;
const int code_mask  = 0x0000000F;

const int M2G_CODE__OK = 0;
const int M2G_CODE__DIE = 1;

const int G2M_CODE__OK = 0;
const int G2M_CODE__ENCODE_RETURN_TOO_LARGE = 1;
const int G2M_CODE__DECODE_RETURN_TOO_LARGE = 2;
const int G2M_CODE__PV_CALL_EXIT = 13;
const int G2M_CODE__PV_TAMPER_M2G = 14;
const int G2M_CODE__SILENT = 15;


int stage_idx = -1;

void out_flush() {
	fflush(mgr2sol[stage_idx]);
}

void write_int(int x, const string& delim="") {
	if (0 >= fprintf(mgr2sol[stage_idx], "%d%s", x, delim.c_str())) {
		log_printf("Could not write int to mgr2sol[%d]\n", stage_idx);
	}
}

void write_pii(const PII& p) {
	write_int(p.X, " ");
	write_int(p.Y, "\n");
}

template<class C>
void write_int_array(const C& c) {
	const int len = sz(c);
	rep(i, len)
		write_int(c[i], ((i == len-1) ? "\n" : " "));
}

void write_secret(int m2g_code = M2G_CODE__OK) {
	write_int(secret_m2g | m2g_code, "\n");
	out_flush();
}

#ifdef __GNUC__
__attribute__ ((format (printf, 2, 3)))
#endif
NORETURN void die(TResult result, const char* format, ...) {
	FMT_TO_RESULT(format, format, message);
	log_printf("Dying with message '%s'\n", message.c_str());
	for (; stage_idx < 2; stage_idx++) {
		log_printf("Sending secret with code DIE to mgr2sol[%d]\n", stage_idx);
		write_secret(M2G_CODE__DIE);
		out_flush();
	}
	log_printf("Quitting with result code %d\n", int(result));
	quit(result, message);
}


int read_int() {
	int x;
	if (1 != fscanf(sol2mgr[stage_idx], "%d", &x)) {
		stage_idx++;
		die(_fail, "Could not read int from sol2mgr[%d]", stage_idx);
	}
	return x;
}

void read_secret() {
	int secret = read_int();
	if((secret & ~code_mask) != secret_g2m)
		die(_pv, "Possible tampering with sol2mgr[%d]", stage_idx);
	int g2m_code = secret & code_mask;
	switch (g2m_code) {
		case G2M_CODE__OK:
			return;
		case G2M_CODE__SILENT:
			die(_fail, "Unexpected g2m_code SILENT from sol2mgr[%d]", stage_idx);
		case G2M_CODE__PV_TAMPER_M2G:
			die(_pv, "Possible tampering with mgr2sol[%d]", stage_idx);
		case G2M_CODE__PV_CALL_EXIT:
			die(_pv, "Solution[%d] called exit()", stage_idx);
		case G2M_CODE__ENCODE_RETURN_TOO_LARGE:
			die(_wa, "Return value of encode is too large");
		case G2M_CODE__DECODE_RETURN_TOO_LARGE:
			die(_wa, "Return value of decode is too large");
		default:
			die(_fail, "Unknown g2m_code %d from sol2mgr[%d]", g2m_code, stage_idx);
	}
}

void read_pii(PII& p) {
	p.X = read_int();
	p.Y = read_int();
}


#define log_var(var_name) log_printf("%s = %s\n", #var_name, toString(var_name).c_str());

template<class C>
void log_print_array(const C& c) {
	rep(i, sz(c))
		log_printf("%s%d", (i?" ":""), c[i]);
	log_printf("\n");
}

void log_print_pii(const PII& p) {
	log_printf("%d %d\n", p.X, p.Y);
}


const bool log_details = false;


const int E_size_multiplier = 6;
const int E_element_limit = 2'000'000'000;


int main(int argc, char **argv) {
	registerManager("treasure", 2, argc, argv);

	// Reading Input
	int subtask_id = inf.readInt();
	int shuffle_seed = inf.readInt();
	int T = inf.readInt();
	log_var(subtask_id);
	log_var(shuffle_seed);
	log_var(T);
	vector<VPII> Ps;
	rep(sc_idx, T) {
		int N = inf.readInt();
		auto& P = Ps.emplace_back(N);
		rep(i, N)
			P[i].X = inf.readInt(), P[i].Y = inf.readInt();
	}

	// Reacting with the encoder
	log_printf("===== Begin the encoding phase =====\n");
	vector<VI> Es;
	stage_idx = 0;
	rep(step_idx, T) {
		const int sc_idx = step_idx;
		log_printf("Step %d, scenario %d:\n", step_idx, sc_idx);
		const auto& P = Ps[sc_idx];
		const int N = sz(P);
		// Sending P
		write_secret();
		log_var(N);
		write_int(N, "\n");
		log_printf("%s\n", (log_details ? "Sending P:" : "Sending P..."));
		rep(i, N) {
			if (log_details) log_print_pii(P[i]);
			write_pii(P[i]);
		}
		out_flush();
		log_printf("--------------------\n");

		// Receiving E
		read_secret();
		const int L = read_int();
		log_var(L);
		auto& E = Es.emplace_back(L);
		log_printf("%s\n", (log_details ? "Receiving E:" : "Receiving E..."));
		rep(i, L) {
			E[i] = read_int();
			if (log_details) log_printf("%d\n", E[i]);
		}

		// Validating E
		const int E_size_slack = 0;
		const int E_size_limit = E_size_multiplier * N + E_size_slack;
		log_var(E_size_limit);
		if (L > E_size_limit)
			die(_wa, "Length of E (%d) exceeds its limit (%d)", L, E_size_limit);
		rep(i, L) {
			if (E[i] < 0)
				die(_wa, "E[%d] (%d) is negative", i, E[i]);
			if (E[i] > E_element_limit)
				die(_wa, "E[%d] (%d) exceeds the limit %d", i, E[i], E_element_limit);
		}
		log_printf("=========================\n");
	}
	{ // Ending the scenarios
		log_printf("===== End the encoding phase =====\n");
		write_secret();
		write_int(-1, "\n");
		out_flush();
	}

	log_printf("===== Begin the shuffling phase =====\n");
	vector<VI> Ss = Es;
	VI sc_perm(T);
	{
		mt19937 rng(shuffle_seed);
		rep(sc_idx, T) {
			if (log_details)
				log_printf("S @scenario %d:\n", sc_idx);
			else
				log_printf("Creating S @scenario %d...\n", sc_idx);
			auto& S = Ss[sc_idx];
			shuffle(all_of(S), rng);
			if (log_details) log_print_array(S);
			log_printf("=========================\n");
		}
		log_printf("%s\n", (log_details ? "Shuffled permutation of scenarios:" : "Shuffling the permutation of scenarios..."));
		iota(all_of(sc_perm), 0);
		shuffle(all_of(sc_perm), rng);
		if (log_details) log_print_array(sc_perm);
	}
	log_printf("===== End the shuffling phase =====\n");

	// Reacting with the decoder
	log_printf("===== Begin the decoding phase =====\n");
	stage_idx = 1;
	rep(step_idx, T) {
		const int sc_idx = sc_perm[step_idx];
		log_printf("Step %d, scenario %d:\n", step_idx, sc_idx);
		const auto& S = Ss[sc_idx];
		const int L = sz(S);
		// Sending S
		write_secret();
		log_var(L);
		write_int(L, "\n");
		log_printf("%s\n", (log_details ? "Sending S:" : "Sending S..."));
		if (log_details) log_print_array(S);
		write_int_array(S);
		out_flush();
		log_printf("--------------------\n");

		// Receiving D
		read_secret();
		int M = read_int();
		log_var(M);
		VPII D(M);
		log_printf("%s\n", (log_details ? "Receiving D:" : "Receiving D..."));
		rep(i, M) {
			read_pii(D[i]);
			if (log_details) log_print_pii(D[i]);
		}

		// Validating D
		auto P = Ps[sc_idx];
		const int N = sz(P);
		if (M != N)
			die(_wa, "Wrong size of D (M=%d, N=%d) in scenario %d", M, N, sc_idx);
		sort(all_of(P));
		sort(all_of(D));
		if (D != P)
			die(_wa, "Wrong value of D in scenario %d", sc_idx);
		log_printf("=========================\n");
	}
	{ // Ending the scenarios
		log_printf("===== End the decoding phase =====\n");
		write_secret();
		write_int(-1, "\n");
		out_flush();
	}

	// Scoring
	log_printf("===== Scoring phase =====\n");
	double K = 0;
	rep(sc_idx, T) {
		const int N = sz(Ps[sc_idx]);
		const int L = sz(Es[sc_idx]);
		double ratio = L / double(N);
		log_printf("Ratio for scenario %d: %lf\n", sc_idx, ratio);
		K = max(K, ratio);
	}
	log_var(K);

	switch (subtask_id) {
		case 0:
		case 1:
			if (K > 4)
				quitf(_wa, "K = %lf > 4", K);
			quit(_ok);
		case 2: {
			auto qp = [K](double score) {
				double full_score = 79;
				log_printf("Giving partial score %lf out of %lf\n", score, full_score);
				quitp(score / full_score, "K = %lf", K);
			};
			if (K <= 3) quit(_ok);
			else if (K <= 4) qp(60);
			else if (K <= 5) qp(30);
			else if (K <= 6) qp(24);
			else /* (6 < K) */
				quitf(_wa, "K = %lf > 6", K);
			break;
		}
		default:
			quitf(_fail, "Unknown subtask_id %d", subtask_id);
	}
	quitf(_fail, "Reached an unreachable code!!!");
}
