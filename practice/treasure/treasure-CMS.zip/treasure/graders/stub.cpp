#include "treasure.h"
#include <cstdio>
#include <cstdlib>
#include <csignal>
#include <algorithm>
#include <string>

using namespace std;


namespace {

/******************************** Begin testlib-related material ********************************/
#ifdef _MSC_VER
#   define NORETURN __declspec(noreturn)
#elif defined __GNUC__
#   define NORETURN __attribute__ ((noreturn))
#else
#   define NORETURN
#endif
/********************************* End testlib-related material *********************************/


// utils

#define rep(i, n) for(int i = 0, i##__n = (int)(n); i < i##__n; ++i)

template<class C> int sz(const C& c) { return std::size(c); }

// grader/manager protocol

typedef pair<int, int> PII;
#define X first
#define Y second

typedef vector<int> VI;
typedef vector<PII> VPII;

const int secret_g2m = 0x60952B90;
const int secret_m2g = 0x046A1620;
const int code_mask  = 0x0000000F;

const int M2G_CODE__OK = 0;
const int M2G_CODE__DIE = 1;

const int G2M_CODE__OK = 0;
const int G2M_CODE__ENCODE_RETURN_TOO_LARGE = 1;
const int G2M_CODE__DECODE_RETURN_TOO_LARGE = 2;
const int G2M_CODE__PV_CALL_EXIT = 13;
const int G2M_CODE__PV_TAMPER_M2G = 14;
const int G2M_CODE__SILENT = 15;


bool exit_allowed = false;

NORETURN void authorized_exit(int exit_code) {
  exit_allowed = true;
  exit(exit_code);
}


FILE* fin = stdin;
FILE* fout = stdout;

void out_flush() {
	fflush(fout);
}

void write_int(int x, const string& delim="") {
	if (0 >= fprintf(fout, "%d%s", x, delim.c_str())) {
		fprintf(stderr, "Could not write int to fout\n");
		authorized_exit(3);
	}
}

void write_pii(const PII& p) {
	write_int(p.X, " ");
	write_int(p.Y, "\n");
}

template<class C>
void write_int_array(const C& c) {
	const int len = sz(c);
	rep(i, len)
		write_int(c[i], ((i == len-1) ? "\n" : " "));
}

void write_secret(int g2m_code = G2M_CODE__OK) {
	write_int(secret_g2m | g2m_code, "\n");
	out_flush();
}

NORETURN void die(int g2m_code) {
	if(g2m_code == G2M_CODE__OK) {
		fprintf(stderr, "Shall not die with code OK\n");
		authorized_exit(5);
	}
	fprintf(stderr, "Dying with code %d\n", g2m_code);
	if(g2m_code != G2M_CODE__SILENT)
		write_secret(g2m_code);
	fclose(fin);
	fclose(fout);
	authorized_exit(0);
}


int read_int() {
	int x;
	if (1 != fscanf(fin, "%d", &x)) {
		fprintf(stderr, "Could not read int from fin\n");
		authorized_exit(3);
	}
	return x;
}

void read_secret() {
	int secret = read_int();
	if((secret & ~code_mask) != secret_m2g)
		die(G2M_CODE__PV_TAMPER_M2G);
	int m2g_code = secret & code_mask;
	if (m2g_code != M2G_CODE__OK)
		die(G2M_CODE__SILENT);
}

void read_pii(PII& p) {
	p.X = read_int();
	p.Y = read_int();
}

void check_exit_protocol() {
  if (!exit_allowed)
    die(G2M_CODE__PV_CALL_EXIT);
}


// grader logic

const int MAX_N = 40'000;
const int MAX_E_LEN = 2 * 6 * MAX_N;
const int MAX_D_LEN = 2 * MAX_N;

NORETURN void run_encoder() {
	while (true) {
		read_secret();
		int N = read_int();
		if (N == -1) break;
		VPII P(N);
		rep(i, N)
			read_pii(P[i]);

		VI E = encode(P);
		int L = sz(E);

		if (L > MAX_E_LEN)
			die(G2M_CODE__ENCODE_RETURN_TOO_LARGE);

		write_secret();
		write_int(L, "\n");
		write_int_array(E);
		out_flush();
	}
	die(G2M_CODE__SILENT);
}

NORETURN void run_decoder() {
	while (true) {
		read_secret();
		int L = read_int();
		if (L == -1) break;
		VI S(L);
		rep(i, L)
			S[i] = read_int();

		VPII D = decode(S);
		int M = sz(D);

		if (M > MAX_D_LEN)
			die(G2M_CODE__DECODE_RETURN_TOO_LARGE);
		
		write_secret();
		write_int(M, "\n");
		rep(i, M)
			write_pii(D[i]);
		out_flush();
	}
	die(G2M_CODE__SILENT);
}


} // namespace


int main(int argc, char **argv){
	signal(SIGPIPE, SIG_IGN);
	atexit(check_exit_protocol);
	at_quick_exit(check_exit_protocol);

	if(argc < 2) {
		fprintf(stderr, "invalid args\n");
		authorized_exit(1);
	}

	string grader_id = argv[1];
	if (grader_id == "0")
		run_encoder();

	if (grader_id == "1")
		run_decoder();

	fprintf(stderr, "invalid grader id: '%s'\n", grader_id.c_str());
	authorized_exit(1);
}
