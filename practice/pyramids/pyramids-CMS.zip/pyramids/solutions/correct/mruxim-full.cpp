#include "pyramids.h"
#include <numeric>
#include <iostream>

using namespace std;

vector<long long> pa, pb;

void init(std::vector<int> A, std::vector<int> B) {
	A.push_back(0);
	B.push_back(0);
	pa.assign(size(A) + 1, 0);
	pb.assign(size(B) + 1, 0);
	exclusive_scan(A.begin(), A.end(), pa.begin(), 0LL);
	exclusive_scan(B.begin(), B.end(), pb.begin(), 0LL);
	//for(int i = 0; i < (int)size(A) + 1; i++) cerr << pa[i] << ' '; cerr << endl;
	//for(int i = 0; i < (int)size(A) + 1; i++) cerr << pb[i] << ' '; cerr << endl;
}

bool can_transform(int L, int R, int X, int Y) {
	return pa[R+1] - pa[L] == pb[Y+1] - pb[X];
}
