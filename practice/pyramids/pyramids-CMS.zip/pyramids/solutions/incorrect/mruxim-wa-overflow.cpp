#include "pyramids.h"
#include <numeric>

using namespace std;

vector<int> pa, pb;

void init(std::vector<int> A, std::vector<int> B) {
	pa.assign(size(A) + 1, 0);
	pb.assign(size(B) + 1, 0);
	partial_sum(A.begin(), A.end(), pa.begin() + 1);
	partial_sum(B.begin(), B.end(), pb.begin() + 1);
}

bool can_transform(int L, int R, int X, int Y) {
	return pa[R+1] - pa[L] == pb[Y+1] - pb[X];
}
