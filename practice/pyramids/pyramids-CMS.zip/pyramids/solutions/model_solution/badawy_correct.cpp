#include <bits/stdc++.h>
#include "pyramids.h"

using namespace std;

const int N=1e5+5;

long long aa[N],bb[N];

void init(vector<int> a,vector<int> b)
{
	for(int i=0;i<(int)a.size();i++)
	{
		aa[i+1]=a[i]+aa[i];
		bb[i+1]=b[i]+bb[i];
	}
}

bool can_transform(int l1,int r1,int l2,int r2)
{
	l1++; r1++; l2++; r2++;
	return (aa[r1]-aa[l1-1])==(bb[r2]-bb[l2-1])&&(r1-l1)==(r2-l2);
}