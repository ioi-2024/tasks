#include "pyramids.h"
#include <cassert>
#include <cstdio>
// BEGIN SECRET
#include <cstdlib>
#include <string>

namespace {

void write_grader_result(std::string grader_result, std::string grader_msg = "") {
  const std::string output_secret = "71f081d8-d38c-3ca1-2b32-7d7cae534c05";
  printf("%s\n", output_secret.c_str());
  printf("%s\n", grader_result.c_str());
  if (!grader_msg.empty())
    printf("%s\n", grader_msg.c_str());
  fflush(stdout);
}

bool exit_allowed = false;

void authorized_exit(int exit_code) {
  exit_allowed = true;
  exit(exit_code);
}

void check_exit_protocol() {
  if (!exit_allowed)
    write_grader_result("PV", "Solution called exit()");
}

} // namespace
// END SECRET

int main() {
  // BEGIN SECRET
  atexit(check_exit_protocol);
  at_quick_exit(check_exit_protocol);
  exit_allowed = true;

  const std::string input_secret = "06bafef6-7ecc-1f73-5165-263c7b3c6cb9";
  char secret[1000];
  assert(1 == scanf("%999s", secret));
  if (std::string(secret) != input_secret) {
    write_grader_result("PV", "Possible tampering with the input");
    fclose(stdout);
    authorized_exit(0);
  }
  // END SECRET
  int N, Q;
  assert(2 == scanf("%d %d", &N, &Q));
  std::vector<int> A(N), B(N);
  for (int i = 0; i < N; i++)
    assert(1 == scanf("%d", &A[i]));
  for (int i = 0; i < N; i++)
    assert(1 == scanf("%d", &B[i]));
  std::vector<int> L(Q), R(Q), X(Q), Y(Q);
  for (int i = 0; i < Q; i++)
    assert(4 == scanf("%d%d%d%d", &L[i], &R[i], &X[i], &Y[i]));
  fclose(stdin);
  // BEGIN SECRET
  exit_allowed = false;
  // END SECRET

  init(A, B);

  std::vector<bool> P(Q);
  for (int i = 0; i < Q; i++)
    P[i] = can_transform(L[i], R[i], X[i], Y[i]);

  // BEGIN SECRET
  write_grader_result("OK");
  // END SECRET
  for (int i = 0; i < Q; i++)
    printf("%d\n", (P[i] ? 1 : 0));
  fclose(stdout);

  // BEGIN SECRET
  exit_allowed = true;
  // END SECRET
  return 0;
}
