#include "testlib.h"
#include <string>

const std::string output_secret = "71f081d8-d38c-3ca1-2b32-7d7cae534c05";

int main(int argc, char* argv[]) {
	registerChecker("pyramids", argc, argv);

	readBothSecrets(output_secret);
	readBothGraderResults();
	compareRemainingLines(3);
}
