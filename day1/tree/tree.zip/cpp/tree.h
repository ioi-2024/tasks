#include <vector>

void init(std::vector<int> P, std::vector<int> W);

long long query(int L, int R);
