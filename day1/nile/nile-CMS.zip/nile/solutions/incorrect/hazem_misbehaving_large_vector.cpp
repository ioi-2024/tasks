#include "bits/stdc++.h"
#include "nile.h"
using namespace std;

vector<long long> calculate_costs(vector<int> W, vector<int> A, vector<int> B, vector<int> E) {
    return vector<long long>(100'000'000, 999'999'999'999'999'999LL);
}
