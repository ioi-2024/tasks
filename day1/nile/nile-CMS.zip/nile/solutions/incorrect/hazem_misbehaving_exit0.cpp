#include "bits/stdc++.h"
#include "nile.h"
using namespace std;

vector<long long> calculate_costs(vector<int> W, vector<int> A, vector<int> B, vector<int> E) {
    exit(0);
}
