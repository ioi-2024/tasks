#include <vector>

void send_message(std::vector<bool> M, std::vector<bool> C);

std::vector<bool> send_packet(std::vector<bool> A);

std::vector<bool> receive_message(std::vector<std::vector<bool>> R);
